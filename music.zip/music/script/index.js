var musicArr = [{
    "name": "一半",
    "src": "./media/一半 - 薛之谦.ogg",
    "Belong": "专辑:1",
    "img": "./img/img.jpg",
    "singer": "薛之谦1",


}, {
    "name": "演员",
    "src": "./media/演员 - 薛之谦.ogg",
    "Belong": "专辑:2",
    "img": "./img/img.jpg",
    "singer": "薛之谦2",


}, {
    "name": "认真的雪",
    "src": "./media/认真的雪 - 薛之谦.ogg",
    "Belong": "专辑:3",
    "img": "./img/img.jpg",
    "singer": "薛之谦3",


}, {
    "name": "丑八怪",
    "src": "./media/丑八怪 - 薛之谦.ogg",
    "Belong": "专辑:4",
    "img": "./img/img.jpg",
    "singer": "薛之谦4",


}, {
    "name": "意外",
    "src": "./media/薛之谦 - 意外.mp3",
    "Belong": "专辑:意外",
    "img": "./img/img.jpg",
    "singer": "薛之谦5",


}]
var i = 0;
var timer = null;
/*开始播放暂停*/
$("#start").on("click", function() {
    if ($(this).hasClass("circle")) {
        if ($(".circle").css("animation-play-state") == "paused") {
            $(".left .line").css({ "transform": "rotate(0)", "transition": "all 2s" })
            $(".circle").css({ "animation-play-state": "running" });
            $("#playbox")[0].play();

        } else {
            $(".left .line").css({ "transform": "rotate(-30deg)", "transition": "all 1s" })

            $("#playbox")[0].pause();



            $(".circle").css({ "animation-play-state": "paused" });

        }


    } else {
        $(".left .line").css({ "transform": "rotate(0)", "transition": "all 2s" })

        $(this).addClass("circle");
        $(".cd").addClass("circle");
        init();
        $("#playbox")[0].volume = $("#playbox")[0].volume - 0.5;
        /*init()代替*/
        /*$("#playbox").attr({ "src": musicArr[i].src });
        $(".cd img").attr({ "src": musicArr[i].img });
        $(".right .title").html(musicArr[i].name);
        $(".right h3").html(musicArr[i].singer + "<span>" + musicArr[i].Belong + "</span>");
        $("#playbox")[0].play();
        jindutiao();*/

    }


})


/*进度条加载*/
function jindutiao() {

    timer = setInterval(function() {
            var allTime = $("#playbox")[0].duration;
            var nowTime = $("#playbox")[0].currentTime;
            var baifenbi = (Math.floor((nowTime / allTime) * 100) + "%")
            $(".time span").eq(0).html(Math.floor(allTime / 60) + ":" + Math.floor(allTime % 60) + " /");
            $(".time span").eq(1).html(Math.floor(nowTime / 60) + ":" + Math.floor(nowTime % 60));
            $(".line-box .line").css({ "width": baifenbi });
            if ($("#danqu").hasClass('circle')) {
                if ($("#playbox")[0].ended == true) {
                    clearInterval(timer);
                    $("#start").trigger("click");

                }
            } else {
                end();
            }

        }, 1000)
        /*歌曲结束自动下一曲*/
    function end() {
        if ($("#playbox")[0].ended == true) {
            clearInterval(timer);
            $("#next").trigger("click");

        }
    }

}
/*下一首*/
$("#next").on("click", function() {

        i++;
        if (i == musicArr.length) {
            i = 0
        }
        /*alert(i)*/

        $(".left .line").css({ "transform": "rotate(0)", "transition": "all 2s" })
        $(".circle").css({ "animation-play-state": "running" });
        $(".cd").addClass("circle");
        $("#start").addClass("circle");
        init();
        /*init()代替*/
        /* $("#playbox").attr({ "src": musicArr[i].src });
         $(".cd img").attr({ "src": musicArr[i].img });
         $(".right .title").html(musicArr[i].name);
         $(".right h3").html(musicArr[i].singer + "<span>" + musicArr[i].Belong + "</span>")
         $("#playbox")[0].play();
         jindutiao();*/



    })
    /*上一首*/
$("#back").on("click", function() {

        i--;
        if (i == -1) {
            i = musicArr.length - 1;
        }
        /*alert(i)*/

        $(".left .line").css({ "transform": "rotate(0)", "transition": "all 2s" })
        $(".circle").css({ "animation-play-state": "running" });
        $(".cd").addClass("circle");
        $("#start").addClass("circle");
        init();
        /*init()代替*/
        /*
            $("#playbox").attr({ "src": musicArr[i].src });
            $(".cd img").attr({ "src": musicArr[i].img });
            $(".right .title").html(musicArr[i].name);
            $(".right h3").html(musicArr[i].singer + "<span>" + musicArr[i].Belong + "</span>")
            $("#playbox")[0].play();
            jindutiao();*/
    })
    /*随机播放按钮 点击后 会直接切歌*/
$("#suiji").on("click", function() {
        var rom = Math.floor((Math.random() * musicArr.length));
        i = rom;
        init();
        $(".left .line").css({ "transform": "rotate(0)", "transition": "all 2s" })
        $("#start").addClass("circle");
        $(".cd").addClass("circle");
        init();

        /*init()代替*/
        /* $("#playbox").attr({ "src": musicArr[i].src });
         $(".cd img").attr({ "src": musicArr[i].img });
         $(".right .title").html(musicArr[i].name);
         $(".right h3").html(musicArr[i].singer + "<span>" + musicArr[i].Belong + "</span>");
         $("#playbox")[0].play();
         jindutiao();*/
    })
    /*音乐加载和更换*/
function init() {
    $("#playbox").attr({ "src": musicArr[i].src });
    $(".cd img").attr({ "src": musicArr[i].img });
    $(".right .title").html(musicArr[i].name);
    $(".right h3").html(musicArr[i].singer + "<span>" + musicArr[i].Belong + "</span>");
    $("#playbox")[0].play();
    jindutiao();
}
$("#danqu").on("click", function() {
        $(this).toggleClass("circle")
    })
    /*静音键 点击静音再次点击恢复 */
$("#sound").on("click", function() {
        var beforeVoi = $("#playbox")[0].volume;
        if ($(this).hasClass("circle")) {
            var nowVoic = $(".show i").html();
            $("#playbox")[0].volume = nowVoic / 10;
            $(this).removeClass('circle')
        } else {
            $("#playbox")[0].volume = "0";
            $(this).addClass('circle')
        }

        /*console.log($("#playbox")[0].volume)*/
    })
    /*音量减小 最小为0*/
$("#desc").on("click", function() {
        var beforeVolume = $("#playbox")[0].volume;
        var nowVolume = beforeVolume - 0.1;
        if (nowVolume <= 0) {
            nowVolume = 0;
        }
        $("#playbox")[0].volume = nowVolume;
        $(".show i").html(Math.floor(nowVolume * 10))
            /*console.log(nowVolume)*/
    })
    /*音量增加 最大为1*/
$("#add").on("click", function() {
    /*   $("#playbox")[0].currentTime += 30;*/
    var beforeVolume = $("#playbox")[0].volume;
    var nowVolume = beforeVolume + 0.1;
    if (nowVolume >= 1) {
        nowVolume = 1;
    }
    $("#playbox")[0].volume = nowVolume;
    $(".show i").html(Math.floor(nowVolume * 10))
        /*console.log(nowVolume)*/
})
/*点击滚动条音乐播放位置跳转 滚动条跳转 移入位置显示*/
$(".line-box").on("mouseover", function(event) {
    var nowweizhi = Math.floor(event.offsetX / parseInt($(this).css("width")) * 100);
    $(this).attr("title", nowweizhi + "%")
    $(this).on("mousemove", function(event) {

        var moveweizhi = Math.floor(event.offsetX / parseInt($(this).css("width")) * 100);
        $(this).attr("title", moveweizhi + "%");
        console.log($(this).attr("title"))

    })

    $(".line-box").on("click", function(event) {
            var nowvoic = event.offsetX / parseInt($(this).css("width")) * $("#playbox")[0].duration;
            $("#playbox")[0].currentTime = nowvoic;
            /*alert(nowweizhi);*/
            /*$(this).find(".line").css({"width":"50%"})*/
        })
        /*alert(nowweizhi);*/
        /*$(this).find(".line").css({"width":"50%"})*/
})
/*div点击事件*/
$("footer section li").on("click",function(){
    i=$(this).index()-1;
    $("#next").trigger('click')
})
loadMusic();
function loadMusic() {
    for(var i=0;i<musicArr.length;i++){
        $("footer section").find("div").eq(i).find("b").html(musicArr[i].name);
        $("footer section").find("div").eq(i).find("i").html(musicArr[i].singer)
    }
    
}
